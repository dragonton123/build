export default function(){
    return[
      {
        id: 1,
        name : 'Mr.json',
        last : 'Potter'
      },
      {
        id: 2,
        name : 'Mrs.magarine',
        last : 'Soberr'
      },
      {
        id: 3,
        name : 'Mrs.carorine',
        last : 'Smit'
      }
    ]
}
