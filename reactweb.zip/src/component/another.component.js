
import React from 'react';


class AnotherComponent extends React.Component {
  render() {
    return (
      <h1>This is an another component </h1>
    );
  }
}


export default AnotherComponent;
