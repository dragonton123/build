import React, { Component } from 'react';
import logo from './image/Piangusol_logo.png';
import { NavItem ,Nav,Navbar,NavDropdown,MenuItem} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap-theme.css';
import './App.css';

import './style/navbarstyle.css'
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
const logo_web = (
    <div className="logo" ><Link to="/"><img src={logo} className="App-logo" alt="logo" /></Link></div>
);

const navbarInstance = (
    <Navbar className="" fixedTop>
        <Navbar.Header>
            <Navbar.Brand>
                {logo_web}
            </Navbar.Brand>
            <Navbar.Toggle />
        </Navbar.Header>
      <Navbar.Collapse>
            <Nav pullRight>
                <NavItem eventKey={1} ><Link className="ared" to="/">หน้าแรก</Link></NavItem>
                <NavItem eventKey={2} ><Link className="ared" to="/real">ค่าเซนเซอร์</Link></NavItem>
                <NavDropdown eventKey={3} className="ared"  title="เรียกดูสถิติ" id="basic-nav-dropdown">
                    <MenuItem eventKey={3.1}  className="ared"><Link className="ared" to={{pathname: "/data",  param : "table"}}>ตาราง</Link></MenuItem>
                    <MenuItem eventKey={3.2}  className="ared"><Link className="ared" to={{pathname: "/data",  param : "chart"}}>กราฟ</Link></MenuItem>
                </NavDropdown>
                <NavItem eventKey={4} ><Link className="ared" to="/status">สถานะเซนเซอร์</Link></NavItem>
                <NavItem eventKey={4} ><Link className="ared" to="/control">ควบคุมอุปกรณ์</Link></NavItem>
                <NavItem eventKey={5} ><Link className="ared"  to="/real">ติดต่อเรา</Link></NavItem>
                <NavItem eventKey={6} onClick={() => Logout()} ><span className="ared" >ออกจากระบบ</span></NavItem>
            </Nav>
      </Navbar.Collapse>
    </Navbar>
);

const button = (
    <div>
        <Button bsStyle="primary" bsSize="large" active>Primary button</Button>
        &nbsp;&nbsp;
        <Button bsStyle="primary" bsSize="large" active>Primary button</Button>
    </div>
);

function Logout() {
    window.localStorage.removeItem("session");
    window.location.reload();
}


class App extends Component {


    showSettings (event) {
     event.preventDefault();

   }

  render() {

    return (
       <div className="App">
       <div>
       </div>
         <div >
         {navbarInstance}
        </div>
        <div className="App-body" >
         <div  id="page-wrap">

           {this.props.children}


           </div>
        </div>
       </div>
     );

  }
}



export default App;
