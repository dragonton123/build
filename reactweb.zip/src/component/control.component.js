
import React from 'react';

import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import {promise} from 'react-promise';
import axios from'axios';
import './style/statusstyle.css';
import {Button,Grid, Row, Col, Clearfix,Label} from 'react-bootstrap';
import Switch from 'react-toggle-switch'
import "./style/toggle-style.css"
const url = localStorage.getItem("url");

const button = (
    <div>
        <Button bsStyle="primary" bsSize="large" active onClick={()=>this.command("esp_rl_1","on")}>Primary button</Button>
        &nbsp;&nbsp;
        <Button bsStyle="primary" bsSize="large" active>Primary button</Button>
    </div>
);

class ControlComponent extends React.Component {

    constructor() {
        super();
        this.state = {
            data: '',
            loading: true,
            tbname: '',
            sh_name: 'วาล์วจ่ายน้ํา',
            switched: false,
            switched_trig:false


        };
    }

    command(name,command){
        if(this.state.switched === true){
            alert("ไม่สามารถทำงานได้ กรุณาปิดระบบอัตโนมัติก่อน");
        }else {
            axios.get(url + '/command', {
                params: {
                    name: name,
                    command: command
                }
            }).then(res => {
                console.log(res.data.status);
                if (command === "on") {
                    if (res.data.status === "sucess") {
                        alert("เปิดการจ่ายน้ำสำเร็จ");
                    } else {
                        alert("ไม่สามารถเปิดการจ่ายน้ำได้");
                    }

                } else if (command === "off") {
                    if (res.data.status === "sucess") {
                        alert("ปิดการจ่ายน้ำสำเร็จ");
                    } else {
                        alert("ไม่สามารถปิดการจ่ายน้ำได้");
                    }

                } else {

                }
            })
                .catch(err => {
                    alert("ไม่สามารถเปิดการจ่ายน้ำได้");
                });
            this.props.setStatus();
        }
 }


 btn1(command){
     if(command === "on"){
         return "buttonactive"
     }else{
         return "button"
     }
 }
 btn2(command){
     if(command === "off"){
         return "buttonactive"
     }else{
         return "button"
     }
 }

    btn_togggle(status){
        if(status === "auto"){
            //return true;
            this.setState({switched: true});

        }else{
            this.setState({switched: false});

        }
    }



    toggleSwitch(command){
        if(command === true){
            axios.get(url + '/command_auto', {
                params: {
                    command: "manual"
                }
            }).then(res => {
                console.log(res.data.status);

                    if (res.data.status === "sucess") {
                        alert("ปิดระบบจ่ายน้ำอัตโนมัติสำเร็จ");
                        // this.setState({switched: false});
                    } else {
                        alert("ไม่สามารถปิดระบบจ่ายน้ำอัตโนมัติได้");
                    }

            })
                .catch(err => {
                    alert("ไม่สามารถปิดระบบจ่ายน้ำอัตโนมัติได้");
                });
            this.props.setStatus();
        }else if(command === false){
            axios.get(url + '/command_auto', {
                params: {
                    command: "auto"
                }
            }).then(res => {
                console.log(res.data.status);

                if (res.data.status === "sucess") {
                    alert("เปิดระบบจ่ายน้ำอัตโนมัติสำเร็จ");
                    // this.setState({switched: true});
                } else {
                    alert("ไม่สามารถเปิดระบบจ่ายน้ำอัตโนมัติได้");
                }

            })
                .catch(err => {
                    alert("ไม่สามารถเปิดระบบจ่ายน้ำอัตโนมัติได้");
                });
            this.props.setStatus();
        }

    };


    componentDidMount(){

        this.props.setStatus()
        this.btn_togggle(this.props.command.resultcommand.status1)
        setInterval(()=>{
            this.props.setStatus()
            this.btn_togggle(this.props.command.resultcommand.status1)
        },10000);
        setInterval(()=>{
            this.btn_togggle(this.props.command.resultcommand.status1)
        },1000);
        setInterval(()=>{
            console.log("sw :"+this.state.switched);
            console.log("db :"+this.props.command.resultcommand.status1);

        },1000);

        setInterval(()=>{
            //this.props.setData(this.state.tbname)
        },60000);
    }

  render() {


    return (

      <div>
        <Grid>
              <Row sm={12} lg={12}>
                  <div className="header">ควบคุมการจ่ายน้ำ</div>
              </Row >
              <br/>

              <Row lg={12}  >
                  <Row>
                      <Col lg={6} >
                          <Row  >

                              <Col lg={6} >
                                  <div className="auto_command">เปิดการจ่ายน้ำอัตโนมัติ
                                  </div>&nbsp;&nbsp;
                              </Col>
                              <Col lg={1}>
                                  <Switch onClick={()=>this.toggleSwitch(this.state.switched)} on={this.state.switched}/>
                              </Col>

                          </Row>
                      </Col>


                  </Row>
                  <br/>
                  <Row>
                      <Col lg={6} >
                          <div className="circle">
                              <div className="name">{this.state.sh_name} 1</div><br/>
                              <div>
                                  <button onClick={()=>this.command("esp_rl_1","on")}
                                          className={this.btn1(this.props.command.resultcommand.command1)}>เปิดการจ่ายน้ำ</button>
                                  &nbsp;&nbsp;
                                  <button onClick={()=>this.command("esp_rl_1","off")}
                                          className={this.btn2(this.props.command.resultcommand.command1)}>ปิดการจ่ายน้ำ</button>
                              </div>

                          </div>
                      </Col>
                      <Col lg={6} >
                          <div className="circle">
                              <div className="name">{this.state.sh_name} 2</div><br/>
                              <div>
                                  <button onClick={()=>this.command("esp_rl_2","on")}
                                              className={this.btn1(this.props.command.resultcommand.command2)}>เปิดการจ่ายน้ำ</button>
                                  &nbsp;&nbsp;
                                  <button onClick={()=>this.command("esp_rl_2","off")}
                                              className={this.btn2(this.props.command.resultcommand.command2)}>ปิดการจ่ายน้ำ</button>
                              </div>

                          </div>
                      </Col>
                  </Row>
              <br/>
                  <Row lg={12}>
                      <Col lg={6} >
                          <div className="circle">
                              <div className="name">{this.state.sh_name} 3</div><br/>
                              <div>
                                  <button onClick={()=>this.command("esp_rl_3","on")}
                                                      className={this.btn1(this.props.command.resultcommand.command3)}>เปิดการจ่ายน้ำ</button>
                                  &nbsp;&nbsp;
                                  <button onClick={()=>this.command("esp_rl_3","off")}
                                                      className={this.btn2(this.props.command.resultcommand.command3)}>ปิดการจ่ายน้ำ</button>
                              </div>

                          </div>
                      </Col>
                      <Col lg={6} >
                          <div className="circle">
                              <div className="name">{this.state.sh_name} 4</div><br/>
                              <div>
                                  <button onClick={()=>this.command("esp_rl_4","on")}
                                                      className={this.btn1(this.props.command.resultcommand.command4)}>เปิดการจ่ายน้ำ</button>
                                  &nbsp;&nbsp;
                                  <button onClick={()=>this.command("esp_rl_4","off")}
                                                      className={this.btn2(this.props.command.resultcommand.command4)}>ปิดการจ่ายน้ำ</button>
                              </div>

                          </div>
                      </Col>
                  </Row>


              </Row>
        </Grid>
      </div>


    );
  }
}

const mapStateToProps = (state) => {
    return{
        user: state.user,
        math: state.math,
        data: state.db,
        realtimedata: state.real,
        status: state.status,
        command: state.command
    };
};
const mapDispatchToprops = (dispatch) =>{
    return{
        setStatus: () =>{
            dispatch({
                type: "FETCH_COMMAND",
                payload :new Promise((resolve,reject) => {
                    setTimeout(()=>{
                        resolve(axios.get(url+'/realtime_command')
                            .then(res => {
                                console.log(res.data);
                                return res.data })
                            .catch(err => { throw err; }));
                    },500);
                })
            });

        }

    };
};

export default withRouter(connect(mapStateToProps, mapDispatchToprops)(ControlComponent));

